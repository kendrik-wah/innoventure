package general_methods;

import java.io.*;
import java.lang.*;
import java.util.*;

import criteria.*;
import inventory.*;
import equipment.*;

public class General_Methods {
	
	public Object[] map(Hashtable inventory_list) { // Use map as a precursor to sorting
		
		Object[] keys = inventory_list.keySet().toArray();
		int number_of_keys = keys.length;
		Object[] object_lst = new Object[number_of_keys];
		
		for (int i = 0; i < number_of_keys; i++) {
			Object key_entry = keys[i];
			object_lst[i] = inventory_list.get(key_entry);
		}
		
		return object_lst;
	}
	
	public static boolean checker(Object o1, Object o2) {
		if ((is_integer(o1) == is_integer(o2) && is_integer(o1) == true) || (is_string(o1) == is_string(o2) && is_string(o1) == true)) {
			return o1 == o2;
		}
		return o1.equals(o2);
	}
	
	public static int string_checker(String s1, String s2) {
		return s1.compareTo(s2);
	}
	
	public static boolean is_integer(Object o) {
		return o.getClass().getName() == "java.lang.Integer";
	}
	
	public static boolean is_string(Object o) {
		return o.getClass().getName() == "java.lang.String";
	}
	
	public void merge(Object[] array, int low, int middle, int high, int order, int... criterion) {
		
		int low_len = middle - low + 1;
		int high_len = high - middle;
		Object sentinel_i;
		Object sentinel_j;
		
		Object low_lst[] = new Object [low_len];
		Object high_lst[] = new Object [high_len];

		for (int i = 0; i < low_len; i++) {
			low_lst[i] = array[i+low];
		}
		for (int j = 0; j < high_len; j++) {
			high_lst[j] = array[j+middle+1];
		}
		
		int i = 0;
		int j = 0;
		int counter = low;
		while (i < low_len && j < high_len) {
			
			boolean result = true;
			
			if (criterion.length == 0) {
				sentinel_i = low_lst[i];
				sentinel_j = high_lst[j];
			}
			
			else {
				sentinel_i = (Object)((Equipment) low_lst[i]).return_criterion(criterion[0]);
				sentinel_j = (Object)((Equipment) high_lst[j]).return_criterion(criterion[0]);
				if (criterion[0] == 0) {
					result = checker(sentinel_i, sentinel_j);
				}
				else {
					result = string_checker((String) sentinel_i, (String) sentinel_j) > 0;
				}
			}
			
			if (order > 0) {
				if (result == true) {
					array[counter] = low_lst[i];
					i = i + 1;
				}
				else {
					array[counter] = high_lst[j];
					j = j + 1;
				}				
			}
			else {
				if (result == true) {
					array[counter] = high_lst[j];
					j = j + 1;
				}
				else {
					array[counter] = low_lst[i];
					i = i + 1;
				}
			}
			counter = counter + 1;
		}
		
		if (order > 0) {
			while (i < low_len) {
				array[counter] = low_lst[i];
				counter = counter + 1;
				i = i + 1;
			}
			
			while (j < high_len) {
				array[counter] = high_lst[j];
				counter = counter + 1;
				j = j + 1;
			}			
		}
		else {
			while (j < high_len) {
				array[counter] = high_lst[j];
				counter = counter + 1;
				j = j + 1;
			}
			while (i < low_len) {
				array[counter] = low_lst[i];
				counter = counter + 1;
				i = i + 1;
			}
		}
	}
	
	public void merge_sort(Object[] inventory, int low, int high, int order, int... criterion) {
		
		if (low < high) {
			int middle = (low + high)/2;
			if (criterion.length == 0) {
				merge_sort(inventory, low, middle, order);
				merge_sort(inventory, middle+1, high, order);
				merge(inventory, low, middle, high, order, criterion);
			}
			else {
				merge_sort(inventory, low, middle, order, criterion);
				merge_sort(inventory, middle+1, high, order, criterion);
				merge(inventory, low, middle, high, order, criterion);
			}
		}
	}
	
}
