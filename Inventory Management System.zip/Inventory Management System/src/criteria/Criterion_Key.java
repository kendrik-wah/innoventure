package criteria;

import java.io.*;
import java.util.*;

public class Criterion_Key {

	private LinkedList <String> _criteria = new LinkedList <String> ();
	
	public void add_criterion(String criterion) {
		if (_criteria.contains(criterion) == true) {
			System.out.println(criterion + " is already accounted for!");
		}
		else {
			_criteria.add(criterion);
//			System.out.println(criterion + " has been added into the key.");
		}
	}
	
	public void add_criteria(String[] criteria) {
		for (String criterion : criteria) {
			add_criterion(criterion);
		}
	}
	
	public LinkedList return_criteria() {
		return _criteria;
	}
	
	public void print_criterion_key() {
		System.out.println(return_criteria());
	}
	
	public void remove_criterion(String criterion) {
		if (_criteria.contains(criterion) == false) {
			System.out.println(criterion + " was never accounted for!");
		}
		else {
			_criteria.remove(criterion);
			System.out.println(criterion + " has been removed from the key.");
		}
	}
	
	public void swap_criteria(String src, String dst) {
		int src_posn = _criteria.indexOf(src);
		int dst_posn = _criteria.indexOf(dst);
		
		if (src_posn == -1 && dst_posn == -1) {
			System.out.println("Both " + src + " and " + dst + " do not exist within the key!");
		}
		else if (src_posn == -1) {
			System.out.println(src + " does not exist within the key!");
		}
		else if (dst_posn == -1) {
			System.out.println(dst + " does not exist within the key!");			
		}
		else {
			int src_len = src.length();
			int dst_len = dst.length();
			_criteria.set(src_posn, _criteria.get(dst_posn) + _criteria.get(src_posn));
			_criteria.set(dst_posn, _criteria.get(src_posn).substring(dst_len, src_len + dst_len));
			_criteria.set(src_posn, _criteria.get(src_posn).substring(0, dst_len));
			
		}
	}
	
	public Object obtain_by_index(int index) { // Gets the criterion object out (an Object to be transformed into a String later)
		
		if (index >= _criteria.size()) {
			System.out.println("Exceeded number of criteria! Maximum number of criterion is " + _criteria.size());
			return _criteria.get(_criteria.size());
		}
		else if (index < 0) {
			System.out.println("No such thing as negative indices! Maximum number of criterion is " + _criteria.size());
			return _criteria.get(0);
		}
		else {
			return _criteria.get(index);
		}
	}
	
	public Object obtain_index_by_name(String criterion) { // To obtain the index number of a criterion by knowing what the String name is
		
		int index = _criteria.indexOf(criterion);
		
		if (index == -1) {
			System.out.println("Criterion does not exist! Below are the criterion that exists:");
			print_criterion_key();
			return _criteria.get(0);
		}
		else {
			return _criteria.get(index);
		}
	}
	
	public int number_of_parameters() {
		return _criteria.size();
	}
	
}
