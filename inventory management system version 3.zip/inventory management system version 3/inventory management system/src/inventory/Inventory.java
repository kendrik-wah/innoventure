package inventory;

import java.util.*;
import java.lang.*;
import java.time.*;
import java.time.format.*;

import criteria.*;
import equipment.*;

public class Inventory{

	private Criterion_Key _header = new Criterion_Key();
	private ArrayList <Equipment> _inventory_list = new ArrayList <> ();
	private int _number_of_parameters = _header.number_of_parameters();
	private int _number_of_items = _inventory_list.size();
	
	public void initialize_header(String[] criteria) {
		int i;
		for (i = 0; i < criteria.length; i++) {
			_header.add_criterion(criteria[i]);
		}
		_number_of_parameters = _header.number_of_parameters();
	}
//
//	static class SortByIndex implements Comparator<Equipment> {
//
//		public int compare(Equipment e1, Equipment e2) {
//
//		}
//	}

	public void sort_inventory(int criterion, int direction) { // 0 for ascending, 1 for descending

		Comparator <Equipment> comparator;
		if (criterion == 0) {
			if (direction == 0) {
				comparator = (e1, e2) -> ((Integer)(e1.return_by_index(0))).compareTo((Integer)(e2.return_by_index(0)));
			}
			else {
				comparator = (e1, e2) -> ((Integer)(e2.return_by_index(0))).compareTo((Integer)(e1.return_by_index(0)));
			}
		}
		else {
			if (direction == 0) {
				comparator = (e1, e2) -> ((String)(e1.return_by_index(criterion))).compareTo((String)(e2.return_by_index(criterion)));
			}
			else {
				comparator = (e1, e2) -> ((String)(e2.return_by_index(criterion))).compareTo((String)(e1.return_by_index(criterion)));
			}
		}
		_inventory_list.sort(comparator);
	}
	
	public Equipment create_equipment(String[] item) {
		Equipment equipment = new Equipment();
		equipment.initialize_object(Integer.parseInt(item[0]), item);
		return equipment;
	}
	
	public void add_item(String[] item) { // Use this to initialize items
		Equipment equipment = create_equipment(item);
		_inventory_list.add(equipment);
		_number_of_items = _number_of_items + 1;
	}
	
	public void initialize_inventory(ArrayList <String[]> item_list) {
		for (int i = 0; i < item_list.size(); i++) {
			if (i == 0) {
				initialize_header(item_list.get(i));
			}
			else {
				add_item(item_list.get(i));
			}
		}
	}

	// Begin printing of sizes //
	public int criteria_size() {
		return _number_of_parameters;
	}

	public int inventory_size() {
		return _number_of_items;
	}
	// End printing of sizes //

	// Begin return for manipulation //
	public Criterion_Key return_parameters() {
		return _header;
	}
	
	public ArrayList return_items() {
		return _inventory_list;
	}

	public ArrayList return_inventory() {
		ArrayList result = new ArrayList();
		result.add(return_parameters());
		result.add(return_items());
		return result;
	}
	// End return for manipulation //

	// Begin print for display //
	public void print_parameters() {
		for (int i = 0; i < criteria_size(); i++) {
			System.out.print(_header.obtain_by_index(i));
			if (i != (_number_of_parameters - 1)) {
				System.out.print(',');
			}
		}
	}
	
	public void print_items() {
		for (int i = 0; i < inventory_size(); i++) {
			System.out.println(_inventory_list.get(i).return_properties());
		}
	}

	public void print_inventory() {
		print_parameters();
		System.out.println();
		print_items();
	}
	// End print for display //

	// Remove item //
	public void remove_item(String[] e) {
		Equipment equipment = new Equipment();
		equipment.initialize_object(Integer.parseInt(e[0]), e);
		for (int i = 0; i < inventory_size(); i++) {
			if (equipment.return_properties().equals(_inventory_list.get(i).return_properties())) {
				System.out.println(i);
				_inventory_list.remove(i);
				_number_of_items--;
				break;
			}
		}
	}

	public void find_expiring_items(String date, String time) {
		String datetime = date + " " + time;
		ArrayList <Equipment> expired_items = new ArrayList <> ();
		DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm");
		LocalDateTime expire_on = LocalDateTime.parse(datetime, date_time_formatter);
		String expire = expire_on.format(date_time_formatter);

		ArrayList <Equipment> expiring = new ArrayList <> ();

		for (int i = 0; i < inventory_size(); i++) {
			if (((String)_inventory_list.get(i).return_by_index(5)).compareTo(datetime) <= 0) {
				expiring.add(_inventory_list.get(i));
			}
		}

		Comparator <Equipment> comparator = (e1, e2) -> ((String)(e1.return_by_index(5))).compareTo((String)(e2.return_by_index(5)));;
		expiring.sort(comparator);

		if (expiring.size() == 0) {
			System.out.println("NOTHING IS EXPIRING WITHIN THE GIVEN DATE AND TIME!");
		}
		else {
			for (int i = 0; i < expiring.size(); i++) {
				System.out.println(expiring.get(i).return_properties());
			}
		}
	}
}