package test_shell;
import java.io.*;
import java.util.*;

import csv_manipulator.*;
import inventory.*;
import criteria.*;
import equipment.*;
import general_methods.*;

public class Test_Shell {

	public static String testfile = "java_csvsplit_import_test.csv";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CSV_Obtainer csv_obtainer = new CSV_Obtainer();
		CSV_Printer printer = new CSV_Printer();
		csv_obtainer.obtain_csv(testfile);
		LinkedList arr = csv_obtainer.return_array();
		Inventory inventory = new Inventory();
		General_Methods methods = new General_Methods();
		
		// Test CSV_Obtainer Methods
//		System.out.println(arr.get(3));
//		System.out.println(csv_obtainer.show_dimensions());
//		System.out.println(Arrays.toString(csv_obtainer.show_dimensions()));
//		System.out.println(csv_obtainer.number_of_rows());
//		System.out.println(csv_obtainer.number_of_cols());
		
		// Test CSV_Printer Methods
		printer.print_table(testfile); //Returns a table of all the values
//		String test_row = printer.toStringRowTable(testfile, 0);
//		System.out.println(test_row);
//		String test_line = printer.toStringItemList(arr, 3);
//		String[] equipment_entry = inventory.ModifyForEquipment(test_line);
////		String[] line = test_line.split(", ");
//		System.out.println(equipment_entry);
		
		//Test Inventory Methods
		inventory.initialize_inventory(arr);
		LinkedList total_list = inventory.return_inventory();
		Hashtable items = inventory.return_items();
//		System.out.println("Ascending: ");
//		inventory.fix_inventory(0, 1);
//		inventory.print_items();
//		inventory.fix_inventory(1, 1);
//		inventory.print_items();
//		inventory.fix_inventory(2, 1);
//		inventory.print_items();
//		System.out.println("\n" + "Descending: ");
//		inventory.fix_inventory(0, -1);
//		inventory.print_items();
//		inventory.fix_inventory(1, -1);
//		inventory.print_items();
//		inventory.fix_inventory(2, -1);
//		inventory.print_items();
//		inventory.find_expiring_items("21-12-2019", "22:59");
	}

}
