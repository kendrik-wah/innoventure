package inventory;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import criteria.*;
import equipment.*;
import csv_manipulator.*;
import general_methods.*;

public class Inventory{
	
	private Criterion_Key _header = new Criterion_Key();
	private Hashtable _inventory_list = new Hashtable();
	private int _number_of_parameters = _header.number_of_parameters();
	private int _key_index = 0;
	private int _number_of_items = _inventory_list.size();
	
	public void initialize_heading(String[] criteria) {
		_header.add_criteria(criteria);
	}

	public static String[] ModifyForEquipment(String item) {
		
		String[] line = item.split(", ");
		int i = 0;
		String[] equipment_entry = new String[line.length-1];
		String datetime = line[line.length-2] + " " + line[line.length - 1];
		
		for (i = 0; i < line.length - 2; i++) {
			equipment_entry[i] = line[i];
		}
		
		equipment_entry[i] = datetime;
		
		return equipment_entry;
	}
	
	public Equipment create_equipment(String item) {
		
		Equipment equipment = new Equipment();
		equipment.initialize_object(item);
		
		return equipment;
	}
	
	public void initialize_item(String item) {
		
		Equipment equipment = create_equipment(item);
		_inventory_list.put(equipment.return_criterion(0), equipment);
		_number_of_items = _number_of_items + 1;
	}
	
	public void initialize_items(LinkedList <String[]> items) {
		
		int list_size = items.size();
		for (int i = 0; i < list_size; i++) {
			
			CSV_Printer printer = new CSV_Printer();
			String item_entry = printer.toStringItemList(items, i);
			initialize_item(item_entry);
		}
	}
	
	public void initialize_inventory(LinkedList <String[]> item_list) {
		
		String[] header = item_list.get(0);
		initialize_heading(header);
		
		item_list.pop();
		initialize_items(item_list);		
	}
	
	public void sort_inventory(int criterion) {
		General_Methods general = new General_Methods();
		Object[] intermediate_list = general.map(_inventory_list);
		general.merge_sort(intermediate_list, 1, _number_of_items, criterion);
		
	}
	
	public int number_of_parameters() {
		return _number_of_parameters;
	}
	
	public int number_of_items() {
		return _number_of_items;
	}
	
	public Criterion_Key return_parameters() {
		return _header;
	}
	
	public Hashtable return_items() {
		return _inventory_list;
	}
	
	public void print_items() {
		
		for (int i = 1; i <= _inventory_list.size(); i++) {
			System.out.println(((Equipment) _inventory_list.get(i)).return_properties());
		}
	}
	
	public LinkedList return_inventory() {
		
		LinkedList result = new LinkedList();
		result.add(return_parameters());
		result.add(return_items());
		
		return result;
	}
	
	public void fix_inventory(int criterion, int order) {
		System.out.println("Sort by " + _header.obtain_by_index(criterion) + ":");
		General_Methods methods = new General_Methods();
		Object[] replicate = methods.map(_inventory_list);
		methods.merge_sort(replicate, 0, replicate.length - 1, order, criterion);
		_inventory_list.clear();
		for (int i = replicate.length; i > 0; i--) {
			int index;
			if (criterion == 0 && order < 0) {
				index = replicate.length - i + 1;
			}
			else {
				index = i;
			}
			((Equipment) replicate[replicate.length - i]).index_change(index);
			_inventory_list.put(i, replicate[replicate.length - i]);
		}
	}
	
//	public void find_expiring_items(String date, String time) {
//		String datetime = date + " " + time;
//		Equipment[] expired_items;
//		DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm");
//		LocalDateTime expire_on = LocalDateTime.parse(datetime, date_time_formatter);
//		String expire = expire_on.format(date_time_formatter);
//
//		Set keys = _inventory_list.keySet();
//		Equipment item = (Equipment) _inventory_list.get(1);
//		System.out.println(item.return_criterion(5));
////		int expiry_date_index = (int) _header.obtain_index_by_name("Expiry Date");
////		System.out.println(_header.obtain_index_by_name("Expiry Date"));
//		System.out.println(expire.getClass());
//		for (int i = 0; i < keys.size(); i++) {
//			Equipment item = (Equipment) _inventory_list.get(i);
//			if (item.return_criterion(expiry_date_index) >= expire_on) {
//
//			}
//		}
//	}
//
}