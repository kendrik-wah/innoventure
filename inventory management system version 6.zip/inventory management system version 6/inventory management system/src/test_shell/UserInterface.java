package test_shell;

import java.io.*;
import java.util.*;
import csv_manipulator.*;
import inventory.*;
import criteria.*;
import equipment.*;

class UserInterface {

    protected static boolean run_interface = false;
    protected static String run_file;
    protected static String command;
    protected static CSV_Obtainer csv_obtainer;
    protected static ArrayList csv_obtainer_output;
    protected static Inventory inventory;
    protected static ArrayList total_inventory;
    protected static ArrayList inventory_items;
    protected static Scanner file_input = new Scanner(System.in);
    protected static Scanner user_command = new Scanner(System.in);
    protected static Scanner input_data = new Scanner(System.in);
    protected static int number_of_parameters;
    protected static int number_of_items;

    public static void display_commands() {

        System.out.println("Press 1 to add an item into the inventory list.");
        System.out.println("Press 2 to remove an item from the inventory list.");
        System.out.println("Press 3 to display the entire inventory.");
        System.out.println("Press 4 to sort the inventory list.");
        System.out.println("Press 5 to find any expired and expiring items relative to a date.");
        System.out.println("Press 6 to find any items input on a particular date.");
        System.out.println("Press 7 to find an item by its name.");
        System.out.println("Press 8 to find items existing within a given location.");
        System.out.println("Press 9 to find all items separated by name.");
        System.out.println("Press 0 to find all items separated by location.");
        System.out.println("Press - to display all available commands.");
        System.out.println("Press = to leave the program.");

    }

    public static void main(String[] args) {

        System.out.println("Welcome to Team HardHats' Inventory Management System Prototype!");

        // Scan filename to parse //
        System.out.println("Enter filename to analyze: ");
        run_file = file_input.next();

        CSV_Obtainer csv_obtainer = new CSV_Obtainer();

        // Obtain and abstract the information within the file to manipulate //
		csv_obtainer.obtain_csv(run_file);
		csv_obtainer_output = csv_obtainer.return_array();
		inventory = new Inventory();
		inventory.initialize_inventory(csv_obtainer_output);
		number_of_parameters = inventory.criteria_size();
		number_of_items = inventory.inventory_size();
		total_inventory = inventory.return_inventory();
		inventory_items = inventory.return_items();

        // Display commands //
        display_commands();

        while (run_interface == true) {

            command = user_command.next();

            if (command == "1") {
                System.out.println("Enter the details of the item according to the following parameters as an array: ");
                System.out.println("[serial_number,name, batch_number, location, expiry_date, expiry_time]");
                System.out.println("Enter expiry_date as follows: dd/MM/uuuu");
                System.out.println("Enter expiry_time as follows: HH:mm");

            }

        }
    }


}
