package equipment;

import java.lang.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

public class Equipment{
	
	private ArrayList _properties = new ArrayList <> ();
	
	public void initialize_object(int index, String[] equipment) {

		for (int i = 0; i < equipment.length; i++) {
			if (i == 0) {
				_properties.add(index);
			}
			else if (i != equipment.length - 2) {
				String intermediate = equipment[i];
				if (i == 1) {
					while (intermediate.length() != 30) {
						intermediate += " ";
					}
				}
				else if (i == 2) {
					while (intermediate.length() != 15) {
						intermediate += " ";
					}
				}
				else if (i == 3) {
					while (intermediate.length() != 15) {
						intermediate += " ";
					}
				}
				_properties.add(intermediate);
			}
			else {

				String date = equipment[i];
				String d[] = date.split("/");
				String formatted_date = new String();
				String time = equipment[i+1];
				String t[] = time.split(":");
				String formatted_time = new String();

				for (int j = 0; j < d.length; j++) {
					if (d[j].length() == 1) {
						d[j] = "0" + d[j];
					}
					formatted_date += (d[j]);
					if (j != d.length - 1) {
						formatted_date += ("/");
					}
				}

				for (int j = 0; j < t.length; j++) {
					if (t[j].length() == 1) {
						t[j] = "0" + t[j];
					}
					formatted_time += (t[j]);
					if (j != t.length - 1) {
						formatted_time += (":");
					}
				}

				DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm");
				LocalDateTime expire_on = LocalDateTime.parse(formatted_date + ' ' + formatted_time, date_time_formatter);

				LocalDateTime input_date = LocalDateTime.now();
				String expire = expire_on.format(date_time_formatter);
				String input = input_date.format(date_time_formatter);
				_properties.add(input);
				_properties.add(expire);
				break;
			}
		}
	}


	public Object return_by_index(int i) {
		return _properties.get(i);
	}
	
	public ArrayList return_properties() {
		return _properties;
	}
	
	public void add_property(String property) {
		_properties.add(property);
	}
	
	public void remove_property(String property) {
		_properties.remove(property);
	}

	public ArrayList filter_by_index(int i) {
		ArrayList a = new ArrayList <> ();
		for (int j = 0; j < _properties.size(); j++) {
			if (j != i) {
				a.add(_properties.get(i));
			}
		}
		return a;
	}
}
