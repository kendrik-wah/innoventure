package equipment;

import java.io.*;
import java.lang.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

import inventory.*;
import criteria.*;

public class Equipment{
	
	private ArrayList _properties = new ArrayList <> (); // LinkedList so that extra criterion can be accounted for when required.
	
	public void initialize_object(int index, String[] equipment) {
		for (int i = 0; i < equipment.length; i++) {
			if (i == 0) {
				_properties.add(index);
			}
			else if (i != equipment.length - 2) {
				_properties.add(equipment[i]);
			}
			else {
				DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm");
				LocalDateTime expire_on = LocalDateTime.parse(equipment[i] + ' ' + equipment[i+1], date_time_formatter);
				LocalDateTime input_date = LocalDateTime.now();
				String expire = expire_on.format(date_time_formatter);
				String input = input_date.format(date_time_formatter);
				_properties.add(input);
				_properties.add(expire);
				break;
			}
		}
	}
	
//	public void index_change(int k) {
//		_properties.remove(0);
//		_properties.addFirst(k);
//	}
//
	public Object return_by_index(int i) {
		return _properties.get(i);
	}
	
	public ArrayList return_properties() {
		return _properties;
	}
	
	public void add_property(String property) {
		_properties.add(property);
	}
	
	public void remove_property(String property) {
		_properties.remove(property);
	}

	public ArrayList filter_by_index(int i) {
		ArrayList a = new ArrayList <> ();
		for (int j = 0; j < _properties.size(); j++) {
			if (j != i) {
				a.add(_properties.get(i));
			}
		}
		return a;
	}
}
