package test_shell;
import java.io.*;
import java.util.*;

import csv_manipulator.*;
import inventory.*;
import criteria.*;
import equipment.*;


public class Test_Shell {

	public static String testfile = "java_csvsplit_import_test.csv";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CSV_Obtainer csv_obtainer = new CSV_Obtainer();
		CSV_Printer printer = new CSV_Printer();
		csv_obtainer.obtain_csv(testfile);
		ArrayList arr = csv_obtainer.return_array();
		Inventory inventory = new Inventory();
		
		// Test CSV_Obtainer Methods
//		for (int i = 0; i < arr.size(); i++) {
//			System.out.println(arr.get(i));
//		}
//		System.out.println(csv_obtainer.number_of_rows()); // 7
//		System.out.println(csv_obtainer.number_of_cols()); // 6
		// End Test
		
//		Test Inventory Methods
		inventory.initialize_inventory(arr);
		ArrayList total_list = inventory.return_inventory();
		HashMap items = inventory.return_items();
//		System.out.println(total_list); // bunch of gibberish, array in array
//		System.out.println(items); // bunch of gibberish, equipment
		System.out.println("Before: ");
		inventory.print_inventory(); // actually shows the inventory
		System.out.println();
		inventory.sort_inventory();
		System.out.println("After: ");
		inventory.print_inventory();
//		inventory.find_expiring_items("21-12-2019", "22:59");

	}

}
