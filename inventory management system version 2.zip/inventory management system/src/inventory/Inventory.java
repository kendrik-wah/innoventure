package inventory;

import java.util.*;

import criteria.*;
import equipment.*;

public class Inventory{
	
	private Criterion_Key _header = new Criterion_Key();
	private HashMap <Integer, Equipment> _inventory_list = new HashMap <> ();
	private int _number_of_parameters = _header.number_of_parameters();
	private int _number_of_items = _inventory_list.size();
	
	public void initialize_header(String[] criteria) {
		int i;
		for (i = 0; i < criteria.length; i++) {
			_header.add_criterion(criteria[i]);
		}
		_number_of_parameters = _header.number_of_parameters();
	}

//	private void sort_map(HashMap <Integer, Equipment> m, int index, int order) {
//		if (index == 0 && order == 0) { // Descending
//			Map<Integer,Equipment> unsortedMap = m;
//			Map<Integer,Equipment> treeMap = new TreeMap<~>(m)(
//					new Comparator<Integer>() {
//						public int compare(Integer o1, Integer o2) {
//							return o2.compareTo(o1);//sort in descending order
//						}
//					});
//		}
//		else if (index == 0 && order == 1) { // Ascending
//			Map<Integer,Equipment> treeMap = new TreeMap<Integer,Equipment>(m);
//		}
//	}

	public void sort_inventory(int c) {
		if (c > _header.number_of_parameters()-1) {
			return;
		}
		Map<Integer, Equipment> map = new TreeMap<>(_inventory_list) ;
		HashMap<Integer, Equipment> result = new HashMap<> ();
		Set <Integer> keys = map.keySet();
		for (Integer i : keys) {
			result.put(i, map.get(i));
		}
		_inventory_list = result;
	}
	
	public Equipment create_equipment(String[] item) {
		Equipment equipment = new Equipment();
		equipment.initialize_object(_number_of_items+1, item);
		return equipment;
	}
	
	public void initialize_item(String[] item) {
		Equipment equipment = create_equipment(item);
		if ((_inventory_list.get((Integer) equipment.return_by_index(0))) != null) { // if the key already exists, then append at the back, create a new entry at the back.
			_inventory_list.put(_number_of_items + 1, equipment);
		}
		else if ((Integer) equipment.return_by_index(0) > (_number_of_items + 1)) { // if the key does not exist but is out of the maximum and next highest, force it to next highest.
			_inventory_list.put(_number_of_items + 1, equipment);
		}
		else {
			_inventory_list.put((Integer) equipment.return_by_index(0), equipment);
		}
		_number_of_items = _number_of_items + 1;
	}
	
	public void initialize_inventory(ArrayList <String[]> item_list) {
		for (int i = 0; i < item_list.size(); i++) {
			if (i == 0) {
				initialize_header(item_list.get(i));
			}
			else {
				initialize_item(item_list.get(i));
			}
		}
	}

	// Begin printing of sizes //
	
	public int criteria_size() {
		return _number_of_parameters;
	}
	
	public int item_size() {
		return _number_of_items;
	}

	// End printing of sizes //

	// Begin return for manipulation //

	public Criterion_Key return_parameters() {
		return _header;
	}
	
	public HashMap return_items() {
		return _inventory_list;
	}

	public ArrayList return_inventory() {
		ArrayList result = new ArrayList();
		result.add(return_parameters());
		result.add(return_items());
		return result;
	}

	// End return for manipulation //

	// Begin print for display //

	public void print_parameters() {
		for (int i = 0; i < criteria_size(); i++) {
			System.out.print(_header.obtain_by_index(i));
			if (i != (_number_of_parameters - 1)) {
				System.out.print(',');
			}
		}
	}
	
	public void print_items() {
		for (int i = 1; i <= item_size(); i++) {
			System.out.print(((Equipment) _inventory_list.get(i)).return_properties());
			if (i != (_number_of_items)) {
				System.out.println();
			}
		}
	}

	public void print_inventory() {
		print_parameters();
		System.out.println();
		print_items();
	}

	// End print for display //

	// Add item //

	public void add_item(String[] e) {
		Equipment equipment = create_equipment(e);
		if ((_inventory_list.get((Integer) equipment.return_by_index(0))) != null) { // if the key already exists, then append at the back, create a new entry at the back.
			_inventory_list.put(_number_of_items + 1, equipment);
		}
		else if ((Integer) equipment.return_by_index(0) > (_number_of_items + 1)) { // if the key does not exist but is out of the maximum and next highest, force it to next highest.
			_inventory_list.put(_number_of_items + 1, equipment);
		}
		else {
			_inventory_list.put((Integer) equipment.return_by_index(0), equipment);
		}
		_number_of_items = _number_of_items + 1;
	}

	// Remove item //

	public void remove_item(String[] e) {
		Equipment equipment = create_equipment(e);
		if ((_inventory_list.get((Integer) equipment.return_by_index(0))) != null) { // if the key already exists, then can remove
			_inventory_list.remove((Integer) equipment.return_by_index(0));
		}
		_number_of_items = _number_of_items - 1;
	}

//	public void find_expiring_items(String date, String time) {
//		String datetime = date + " " + time;
//		Equipment[] expired_items;
//		DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm");
//		LocalDateTime expire_on = LocalDateTime.parse(datetime, date_time_formatter);
//		String expire = expire_on.format(date_time_formatter);
//
//		Set keys = _inventory_list.keySet();
//		Equipment item = (Equipment) _inventory_list.get(1);
//		System.out.println(item.return_criterion(5));
////		int expiry_date_index = (int) _header.obtain_index_by_name("Expiry Date");
////		System.out.println(_header.obtain_index_by_name("Expiry Date"));
//		System.out.println(expire.getClass());
//		for (int i = 0; i < keys.size(); i++) {
//			Equipment item = (Equipment) _inventory_list.get(i);
//			if (item.return_criterion(expiry_date_index) >= expire_on) {
//
//			}
//		}
//	}
//
}