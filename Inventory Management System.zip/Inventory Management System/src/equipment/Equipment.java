package equipment;

import java.io.*;
import java.lang.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

import inventory.*;
import criteria.*;

public class Equipment{
	
	private LinkedList _properties = new LinkedList(); // LinkedList so that extra criterion can be accounted for when required.
	
	public String[] initialize_object(String equipment) {
		
		Inventory inventory = new Inventory();
		
		String[] equipment_entry = inventory.ModifyForEquipment(equipment);
		
		for (int i = 0; i < equipment_entry.length; i++) {
			if (i == 0) {
				_properties.add((Integer.parseInt(equipment_entry[i])));
			}
			else if (i != equipment_entry.length - 1) {
				_properties.add(equipment_entry[i]);
			}
			else {
				DateTimeFormatter date_time_formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm");
				LocalDateTime expire_on = LocalDateTime.parse(equipment_entry[i], date_time_formatter);
				LocalDateTime input_date = LocalDateTime.now();
				String expire = expire_on.format(date_time_formatter);
				String input = input_date.format(date_time_formatter);
				_properties.add(input);
				_properties.add(expire);
			}
		}
		
		return equipment_entry;
	}
	
	public void index_change(int k) {
		_properties.remove(0);
		_properties.addFirst(k);
	}
	
	public Object return_criterion(int criterion) {
		return _properties.get(criterion);
	}
	
	public LinkedList return_properties() {
		return _properties;
	}
	
	public void add_property(String property) {
		_properties.add(property);
	}
	
	public void remove_property(String property) {
		_properties.remove(property);
	}
}
